struct InformaticoStruct;
typedef struct InformaticoStruct* Informatico;
//Se crea la variable puntero llamada Informatico
//a partir del struct InformaticoStruct


// funcion de imprimir de informatico
Informatico imprimir();
Informatico hacer();
Informatico reportar();
Informatico reconocer_objetivo();
Informatico analizar_vulnerabilidades();
Informatico explotar_vulnerabilidades();
/*TDA <INFORMÁTICO>
<Object Hacker>
<Atributos>
Conocimiento informático
Curiosidad
<Métodos>
Reconocer objetivo
Analizar vulnerabilidades
Explotar vulnerabilidades
Reportar
*/